package com.example.demo.model;


import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

@Entity(name = "client")
public class User {
    private int id;
    private String firstName;
    private String lastName;
    private String username;
    private String password;
    private boolean role;
    private List<Medicament> medicaments;


    public @Id @GeneratedValue(strategy = GenerationType.AUTO) int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getFirstName() { return this.firstName; }
    public void setFirstName(String firstName) { this.firstName = firstName; }

    public String getLastName() { return this.lastName; }
    public void setLastName(String lastName) { this.lastName = lastName; }

    public String getUsername() { return this.username; }
    public void setUsername(String username) { this.username = username; }

    public String getPassword() { return this.password; }
    public void setPassword(String password) { this.password = password; }

    public boolean getRole() { return this.role; }
    public void setRole(boolean role) { this.role = role; }

    @ManyToMany(cascade = {
            CascadeType.PERSIST,
            CascadeType.MERGE
    }, fetch = FetchType.EAGER)
    @JoinTable(name = "user_medicament",
            joinColumns = @JoinColumn(name = "user_id"),
            inverseJoinColumns = @JoinColumn(name = "medicament_id")
    )
    public List<Medicament> getMedicaments() { return this.medicaments; }
    public void setMedicaments(List<Medicament> list) { this.medicaments = list; }
    public void addMedicament(Medicament medicament) {
        this.medicaments.add(medicament);
        medicament.getUsers().add(this);
    }
    public void removeMedicament(Medicament medicament) {
        this.medicaments.remove(medicament);
        medicament.getUsers().remove(this);
    }

    public void fill(String firstName, String lastName, String username, String password) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.username = username;
        this.password = password;
    }
}