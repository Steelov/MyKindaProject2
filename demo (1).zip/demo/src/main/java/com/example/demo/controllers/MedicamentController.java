package com.example.demo.controllers;

import com.example.demo.Exceptions.NotFoundException;
import com.example.demo.model.Medicament;
import com.example.demo.model.User;
import com.example.demo.repositories.MedicamentRepository;
import com.example.demo.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.view.RedirectView;

import javax.servlet.http.HttpSession;
import java.util.Map;

@Controller
@RequestMapping("medicament")
public class MedicamentController {
    @Autowired
    MedicamentRepository medicamentRepository;
    @Autowired
    UserRepository userRepository;

    @PostMapping("create")
    public RedirectView create(RedirectAttributes attributes, @RequestParam Map<String, String> payload, HttpSession session) {
        if (session.getAttribute("auth") != null) {
            int id = (int) session.getAttribute("auth");
            User user = userRepository.findById(id).orElseThrow(NotFoundException::new);
            if (user.getRole()) {
                String name = payload.get("name");
                String description = payload.get("description");
                String benefits = payload.get("benefits");
                String components = payload.get("components");
                String image = payload.get("image");

                Medicament newMedicament = new Medicament();
                newMedicament.fill(name, description, image, benefits, components);
                medicamentRepository.save(newMedicament);
                attributes.addAttribute("message", "Successfully created");
            } else {
                attributes.addAttribute("error", "Not permitted");
            }
            return new RedirectView("/medicament/add");
        } else return new RedirectView("/user/sign-in");
    }

    @GetMapping("{id}/add")
    public RedirectView addToUser(RedirectAttributes attributes, Model model, @PathVariable int id, HttpSession session) {
        if (session.getAttribute("auth") != null) {
            int userId = (int) session.getAttribute("auth");
            model.addAttribute("auth", userId);
            User user = userRepository.findById(userId).orElseThrow(NotFoundException::new);
            Medicament medicament = medicamentRepository.findById(id).orElseThrow(NotFoundException::new);

            if (!user.getMedicaments().contains(medicament)) {
                user.addMedicament(medicament);
            }
            attributes.addAttribute("message", "Successfully added");
            return new RedirectView("/medicament/"+id);
        } else {
            return new RedirectView("/user/sign-in");
        }
    }

    @GetMapping("{id}/delete")
    public RedirectView deleteFromUser(RedirectAttributes attributes, Model model, @PathVariable int id, HttpSession session) {
        if (session.getAttribute("auth") != null) {
            int userId = (int) session.getAttribute("auth");
            model.addAttribute("auth", userId);
            User user = userRepository.findById(userId).orElseThrow(NotFoundException::new);
            Medicament medicament = medicamentRepository.findById(id).orElseThrow(NotFoundException::new);

            if (user.getMedicaments().contains(medicament)) {
                user.removeMedicament(medicament);
            }
            attributes.addAttribute("message", "Successfully removed");
            return new RedirectView("/medicament/"+id);
        } else {
            return new RedirectView("/user/sign-in");
        }
    }

    @GetMapping("add")
    public String add(Model model, @RequestParam Map<String, String> payload, HttpSession session) {
        model.addAttribute("auth", session.getAttribute("auth"));

        String message = payload.get("message");
        String error = payload.get("error");
        model.addAttribute("message", message);
        model.addAttribute("error", error);
        return "addMedicament";
    }

    @GetMapping("{id}")
    public String medicament(Model model, @PathVariable int id, HttpSession session, @RequestParam Map<String, String> payload) {
        int userId = (int) session.getAttribute("auth");
        model.addAttribute("auth", userId);
        User user = userRepository.findById(userId).orElseThrow(NotFoundException::new);
        String message = payload.get("message");
        model.addAttribute("message", message);

        Medicament medicament = medicamentRepository.findById(id).orElseThrow(NotFoundException::new);
        model.addAttribute("medicament", medicament);

        model.addAttribute("contains", user.getMedicaments().contains(medicament));
        return "medicament";
    }
}
