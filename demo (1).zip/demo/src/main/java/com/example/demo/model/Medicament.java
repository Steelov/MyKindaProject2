package com.example.demo.model;


import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

@Entity
public class Medicament {
    private int id;
    private String name;
    private String description;
    private String image;
    private String benefits;
    private String components;
    private List<User> users;

    public @Id @GeneratedValue(strategy = GenerationType.AUTO) int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getName() { return this.name; }
    public void setName(String name) { this.name = name; }

    public @Lob String getDescription() { return this.description; }
    public void setDescription(String description) { this.description = description; }

    public String getImage() { return this.image; }
    public void setImage(String image) { this.image = image; }

    public @Lob String getBenefits() { return this.benefits; }
    public void setBenefits(String benefits) { this.benefits = benefits; }

    public @Lob String getComponents() { return this.components; }
    public void setComponents(String components) { this.components = components; }

    @ManyToMany(mappedBy = "medicaments")
    public List<User> getUsers() { return this.users; }
    public void setUsers(List<User> users) { this.users = users; }

    public void fill(String name, String description, String image, String benefits, String components) {
        this.name = name;
        this.description = description;
        this.image = image;
        this.benefits = benefits;
        this.components = components;
    }
}