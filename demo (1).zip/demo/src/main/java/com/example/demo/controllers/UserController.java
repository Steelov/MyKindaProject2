package com.example.demo.controllers;

import com.example.demo.Exceptions.AlreadyRegisteredException;
import com.example.demo.Exceptions.NotFoundException;
import com.example.demo.model.User;
import com.example.demo.repositories.UserRepository;
import com.google.gson.Gson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.view.RedirectView;

import javax.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@Controller
@RequestMapping("user")
public class UserController {
    @Autowired
    private UserRepository userRepository;

    @PostMapping("register")
    public RedirectView register(RedirectAttributes attributes, @RequestParam Map<String, String> payload, HttpSession session) {
        Gson gson = new Gson();
        String firstName = payload.get("firstName");
        String lastName = payload.get("lastName");
        String username = payload.get("username");
        String password = payload.get("password");

        User foundUser = userRepository.findByUsername(username);
        if (foundUser == null) {
            User newUser = new User();
            newUser.fill(firstName, lastName, username, password);
            userRepository.save(newUser);
            session.setAttribute("auth", newUser.getId());

            return new RedirectView("/");
        } else {
            attributes.addAttribute("error", "Already registered");
            return new RedirectView("/user/sign-up");
        }
    }

    @PostMapping("auth")
    public RedirectView auth(RedirectAttributes attributes, @RequestParam Map<String, String> payload, HttpSession session) {
        String username = payload.get("username");
        String password = payload.get("password");
        User foundUser = userRepository.findByUsernameAndPassword(username, password);
        if (foundUser == null) {
            attributes.addAttribute("error", "Wrong credentials");
            return new RedirectView("/user/sign-in");
        } else {
            session.setAttribute("auth", foundUser.getId());
            return new RedirectView("/");
        }
    }

    @PostMapping("update")
    public RedirectView update(RedirectAttributes attributes, @RequestParam Map<String, String> payload, HttpSession session) {
        String firstName = payload.get("firstName");
        String lastName = payload.get("lastName");
        String username = payload.get("username");
        if (session.getAttribute("auth") != null) {
            int id = (int) session.getAttribute("auth");
            User foundUser = userRepository.findById(id).orElseThrow(NotFoundException::new);
            foundUser.setFirstName(firstName);
            foundUser.setLastName(lastName);
            foundUser.setUsername(username);
            userRepository.save(foundUser);
            attributes.addAttribute("message", "Successfully updated");
            return new RedirectView("/user/profile");
        } else {
            attributes.addAttribute("error", "Something went wrong");
            return new RedirectView("/user/profile");
        }
    }

    @GetMapping("profile")
    public String profile(Model model, @RequestParam Map<String, String> payload, HttpSession session) {
        String message = payload.get("message");
        String error = payload.get("error");
        if (session.getAttribute("auth") != null) {
            int id = (int) session.getAttribute("auth");
            model.addAttribute("auth", id);
            User user = userRepository.findById(id).orElseThrow(NotFoundException::new);
            model.addAttribute("user", user);
        }
        model.addAttribute("message", message);
        model.addAttribute("error", error);
        return "profile";
    }

    @GetMapping("sign-up")
    public String signUp(Model model, @RequestParam Map<String, String> payload, HttpSession session) {
        String error = payload.get("error");
        if (session.getAttribute("auth") != null) {
            model.addAttribute("auth", session.getAttribute("auth"));
        }
        model.addAttribute("error", error);
        return "signup";
    }

    @GetMapping("sign-in")
    public String signIn(Model model, @RequestParam Map<String, String> payload, HttpSession session) {
        String error = payload.get("error");
        if (session.getAttribute("auth") != null) {
            model.addAttribute("auth", session.getAttribute("auth"));
        }
        model.addAttribute("error", error);
        return "signin";
    }

    @GetMapping("logout")
    public RedirectView get(HttpSession session) {
        session.removeAttribute("auth");
        return new RedirectView("/");
    }
}
