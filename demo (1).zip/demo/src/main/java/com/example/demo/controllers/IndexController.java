package com.example.demo.controllers;

import com.example.demo.Exceptions.NotFoundException;
import com.example.demo.model.Medicament;
import com.example.demo.model.User;
import com.example.demo.repositories.MedicamentRepository;
import com.example.demo.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpSession;
import java.util.List;


@Controller
@RequestMapping("")
public class IndexController {
    @Autowired
    MedicamentRepository medicamentRepository;
    @Autowired
    UserRepository userRepository;

    @GetMapping()
    public String get(Model model, HttpSession session) {
        if (session.getAttribute("auth") != null) {
            model.addAttribute("auth", session.getAttribute("auth"));
        }
        List<Medicament> medicaments = medicamentRepository.findAll();
        model.addAttribute("medicaments", medicaments);

        return "index";
    }

    @GetMapping("my")
    public String my(Model model, HttpSession session) {
        if (session.getAttribute("auth") != null) {
            int userId = (int) session.getAttribute("auth");
            model.addAttribute("auth", userId);
            User user = userRepository.findById(userId).orElseThrow(NotFoundException::new);

            List<Medicament> medicaments = user.getMedicaments();
            model.addAttribute("medicaments", medicaments);
        }
//        List<Medicament> medicaments = medicamentRepository.findAll();
//        model.addAttribute("medicaments", medicaments);

        return "myMedicaments";
    }
}
